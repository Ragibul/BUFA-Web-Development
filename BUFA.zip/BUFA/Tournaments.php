 <!DOCTYPE html>
<html>
<head>
     <meta charset='utf-8'>
   <link rel="stylesheet" href="styles.css">
   <style type="text/css">
   .News {
	font-family: Cambria, Hoefler Text, Liberation Serif, Times, Times New Roman, serif;
}
   </style>
   <title>BUFA||Bangladesh University Football Association</title>
</head>
   <body>
<img src="img/logo.jpg" alt="HTML5 Icon" style="width:128px;height:128px;">
   <div class="bufa" style="float:right;color:#FF6600;margin:30px;">
     <h1>
     Bangladesh University Football Association
     <h1>
   </div>
   <div id='cssmenu'>
     <ul>
       <li><a href='Home.html'>HOME</a></li>
       <li><a href='Players.html'>PLAYERS</a></li>
       <li><a href='Teams.html'>TEAMS</a></li>
       <li><a href='Tournaments.html'>TOURNAMENTS</a></li>
       <li><a href='#'>DISCUSSION</a></li>
       <li><a href='#'>PHOTOS</a></li>
       <li><a href='#'>VIDEOS</a></li>
       <li><a href='#'>ABOUT US</a></li>
      
     </ul>
   </div>
   
   <section class="Tournaments" align="left">
      <h1>Ongoing Tournaments</h1>
       <ol>
       <li>NSU Gold Cup</li>
       <li>Inter University Challange Cup</li>
       <li>PRAN-RFL Super Cuo </li>
       
       </ol>
   </section>
   <aside class="Upcoming"> 
        <h1>Upcoming Tournaments </h1>
       <ol>
       <li> National Inter University Championship</li>
       <li> BFF Champions Cup</li>
       <li> Dhaka Super Cup</li>
       
       </ol> 
   
     
   </aside>
<div class="footer" style="color:#FF6600"><span>Copyright BUFA||Bangladesh University Football Association, 2015</span></div>
   </body>
</html> 